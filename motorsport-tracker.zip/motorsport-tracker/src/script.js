// Official 2026 Drivers Championship (WDC) Standings
const driverStandingsData = [
    { rank: 1, name: "Andrea Kimi Antonelli", team: "Mercedes AMG", points: 320 },
    { rank: 2, name: "George Russell", team: "Mercedes AMG", points: 236 },
    { rank: 3, name: "Lewis Hamilton", team: "Scuderia Ferrari", points: 214 },
    { rank: 4, name: "Charles Leclerc", team: "Scuderia Ferrari", points: 191 },
    { rank: 5, name: "Lando Norris", team: "McLaren F1 Team", points: 188 },
    { rank: 6, name: "Max Verstappen", team: "Red Bull Racing", points: 188 },
    { rank: 7, name: "Oscar Piastri", team: "McLaren F1 Team", points: 128 },
    { rank: 8, name: "Isack Hadjar", team: "Red Bull Racing", points: 96 },
    { rank: 9, name: "Liam Lawson", team: "Racing Bulls", points: 65 },
    { rank: 10, name: "Pierre Gasly", team: "Alpine F1 Team", points: 41 },
    { rank: 11, name: "Arvid Lindblad", team: "Racing Bulls", points: 38 },
    { rank: 12, name: "Franco Colapinto", team: "Alpine F1 Team", points: 27 },
    { rank: 13, name: "Oliver Bearman", team: "TGR Haas", points: 20 },
    { rank: 14, name: "Gabriel Bortoleto", team: "Audi Works Team", points: 10 },
    { rank: 15, name: "Nico Hulkenberg", team: "Audi Works Team", points: 7 },
    { rank: 16, name: "Esteban Ocon", team: "TGR Haas", points: 7 },
    { rank: 17, name: "Fernando Alonso", team: "Aston Martin Honda", points: 7 },
    { rank: 18, name: "Carlos Sainz Jr.", team: "Williams Racing", points: 7 },
    { rank: 19, name: "Alexander Albon", team: "Williams Racing", points: 5 },
    { rank: 20, name: "Yuki Tsunoda", team: "Aston Martin Honda", points: 1 },
    { rank: 21, name: "Lance Stroll", team: "Williams Racing", points: 0 },
    { rank: 22, name: "Valtteri Bottas", team: "Cadillac F1 Team", points: 0 },
    { rank: 23, name: "Sergio Perez", team: "Cadillac F1 Team", points: 0 }
];

// Official 2026 Constructors Championship (WCC) Standings
const constructorStandingsData = [
    { rank: 1, team: "Mercedes AMG Petronas", points: 556 },
    { rank: 2, team: "Scuderia Ferrari HP", points: 405 },
    { rank: 3, team: "McLaren F1 Team", points: 316 },
    { rank: 4, team: "Red Bull Racing", points: 298 },
    { rank: 5, team: "Racing Bulls", points: 103 },
    { rank: 6, team: "Alpine F1 Team", points: 68 },
    { rank: 7, team: "TGR Haas F1 Team", points: 27 },
    { rank: 8, team: "Audi Works F1 Team", points: 17 },
    { rank: 9, team: "Williams Racing", points: 12 },
    { rank: 10, team: "Aston Martin Aramco Honda", points: 8 },
    { rank: 11, team: "Cadillac F1 Team", points: 0 }
];

// Official Classification Results from Singapore GP Sprint Qualifying Session
const lastSessionResultsData = [
    { pos: 1, no: "1", driver: "Max Verstappen", team: "Red Bull Racing", time: "1:31.156", gap: "POLE" },
    { pos: 2, no: "63", driver: "George Russell", team: "Mercedes AMG", time: "1:31.276", gap: "+0.120" },
    { pos: 3, no: "16", driver: "Charles Leclerc", team: "Scuderia Ferrari", time: "1:31.332", gap: "+0.176" },
    { pos: 4, no: "81", driver: "Oscar Piastri", team: "McLaren F1 Team", time: "1:31.402", gap: "+0.246" },
    { pos: 5, no: "4", driver: "Lando Norris", team: "McLaren F1 Team", time: "1:31.422", gap: "+0.266" },
    { pos: 6, no: "44", driver: "Lewis Hamilton", team: "Scuderia Ferrari", time: "1:31.540", gap: "+0.384" },
    { pos: 7, no: "12", driver: "Andrea Kimi Antonelli", team: "Mercedes AMG", time: "1:31.615", gap: "+0.459" },
    { pos: 8, no: "5", driver: "Isack Hadjar", team: "Red Bull Racing", time: "1:31.890", gap: "+0.734" },
    { pos: 9, no: "30", driver: "Liam Lawson", team: "Racing Bulls", time: "1:31.992", gap: "+0.836" },
    { pos: 10, no: "10", driver: "Pierre Gasly", team: "Alpine F1 Team", time: "1:32.085", gap: "+0.929" },
    { pos: 11, no: "2", driver: "Arvid Lindblad", team: "Racing Bulls", time: "1:32.140", gap: "+0.984" },
    { pos: 12, no: "43", driver: "Franco Colapinto", team: "Alpine F1 Team", time: "1:32.290", gap: "+1.134" },
    { pos: 13, no: "87", driver: "Oliver Bearman", team: "TGR Haas", time: "1:32.312", gap: "+1.156" },
    { pos: 14, no: "5", driver: "Gabriel Bortoleto", team: "Audi Works Team", time: "1:32.505", gap: "+1.349" },
    { pos: 15, no: "27", driver: "Nico Hulkenberg", team: "Audi Works Team", time: "1:32.610", gap: "+1.454" },
    { pos: 16, no: "31", driver: "Esteban Ocon", team: "TGR Haas", time: "1:32.685", gap: "+1.529" },
    { pos: 17, no: "14", driver: "Fernando Alonso", team: "Aston Martin Honda", time: "1:32.740", gap: "+1.584" },
    { pos: 18, no: "55", driver: "Carlos Sainz Jr.", team: "Williams Racing", time: "1:32.812", gap: "+1.656" },
    { pos: 19, no: "23", driver: "Alexander Albon", team: "Williams Racing", time: "1:32.905", gap: "+1.749" },
    { pos: 20, no: "22", driver: "Yuki Tsunoda", team: "Aston Martin Honda", time: "1:33.220", gap: "+2.064" },
    { pos: 21, no: "18", driver: "Lance Stroll", team: "Williams Racing", time: "1:33.511", gap: "+2.355" },
    { pos: 22, no: "77", driver: "Valtteri Bottas", team: "Cadillac F1 Team", time: "1:34.015", gap: "+2.859" },
    { pos: 23, no: "11", driver: "Sergio Perez", team: "Cadillac F1 Team", time: "1:34.420", gap: "+3.264" }
];

function initializeF1Data() {
    const wdcBody = document.getElementById('wdc-table-body');
    const wccBody = document.getElementById('wcc-table-body');
    const resultsBody = document.getElementById('results-table-body');

    if (wdcBody) {
        wdcBody.innerHTML = driverStandingsData.map(d => `
            <tr>
                <td class="col-pos">${d.rank}</td>
                <td class="col-driver">${d.name}</td>
                <td class="col-team">${d.team}</td>
                <td class="col-pts text-right">${d.points}</td>
            </tr>
        `).join('');
    }

    if (wccBody) {
        wccBody.innerHTML = constructorStandingsData.map(c => `
            <tr>
                <td class="col-pos">${c.rank}</td>
                <td class="col-driver">${c.team}</td>
                <td class="col-pts text-right">${c.points}</td>
            </tr>
        `).join('');
    }

    if (resultsBody) {
        resultsBody.innerHTML = lastSessionResultsData.map(r => `
            <tr>
                <td class="col-pos">${r.pos}</td>
                <td class="col-no">${r.no}</td>
                <td class="col-driver">${r.driver}</td>
                <td class="col-team">${r.team}</td>
                <td class="col-time">${r.time}</td>
                <td class="col-gap text-right">${r.gap}</td>
            </tr>
        `).join('');
    }
}

// Safety window handler checks DOM status to prevent CodePen blank render bugs
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initializeF1Data);
} else {
    initializeF1Data();
}

function switchTab(tabId) {
    document.querySelectorAll('.f1-view-panel').forEach(view => view.classList.remove('active'));
    document.querySelectorAll('.nav-tab').forEach(tab => tab.classList.remove('active'));
    
    const selectedView = document.getElementById(`tab-${tabId}`);
    if (selectedView) selectedView.classList.add('active');
    
    if (window.event && window.event.target) {
        window.event.target.classList.add('active');
    }
}

function setAppTheme(themeId) {
    document.documentElement.setAttribute('data-theme', themeId);
}
